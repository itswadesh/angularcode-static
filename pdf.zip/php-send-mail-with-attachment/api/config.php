<?php
define('DATABASE_HOST', "localhost");
define('DATABASE_NAME', "demos");
define('DATABASE_USERNAME', "itswadesh");
define('DATABASE_PASSWORD', "swadesh0");

define('ATTACHED_FILENAME', "books.pdf");

define('SENDGRID_USERNAME', "itswadesh");
define('SENDGRID_PASSWORD', "swadesh0");

define('FROM', "demo@angularcode.com");
define('TO', "support@codenx.com");
define('SUBJECT', "ShopNx - The Single Page eCommerce Website");
define('CONTENT', "
    <h1>Experience faster shopping with ShopNx</h1>
    <ul> 
      <li>Responsive Design</li> 
      <li>Higher Scalability</li> 
      <li>Ergonomically Designed</li> 
    </ul>");

?>